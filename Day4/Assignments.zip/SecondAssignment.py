#!/usr/bin/env python
# coding: utf-8

# In[3]:


name='debanjana'
print(name.islower())


# In[4]:


name='Debanjana'
print(name.islower())


# In[5]:


name='debanjana@@'
print(name.islower())


# In[6]:


name='debanjana123'
print(name.islower())


# In[7]:


name='debanjana-=_+*()'
print(name.islower())


# In[8]:


name='DEBANJANA'
print(name.isupper())


# In[9]:


name='DEBANJAN@@A'
print(name.isupper())


# In[10]:


name='DEB132ANJANA'
print(name.isupper())


# In[11]:


name='DEBANJANA./;[]'
print(name.isupper())


# In[12]:


name='DEBANJaNA'
print(name.isupper())


# In[ ]:




